package Lab;
//Concrete Creator: PdfApplication
public class PdfApplication extends Application{
	 @Override
	    public Document createDocument() {
	        return new PdfDocument();
	    }

}
