package Lab;

abstract class Application {
	
	 // Factory Method
    public abstract Document createDocument();
    
    public void newDocument() {
        Document document = createDocument();
        document.open();
        document.close();
        document.save();
    }
}
