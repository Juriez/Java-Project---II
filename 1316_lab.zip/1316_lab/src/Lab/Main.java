package Lab;

public class Main {
	 public static void main(String[] args) {
	        Application textApp = new TextApplication();
	        textApp.newDocument();
	        
	        Application pdfApp = new PdfApplication();
	        pdfApp.newDocument();
	    }

}
