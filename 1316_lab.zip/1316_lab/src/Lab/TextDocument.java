package Lab;

public class TextDocument implements Document {
	@Override
    public void open() {
        System.out.println("Open text Document ");
    }
	@Override
    public void save() {
        System.out.println("Text Document is saved");
    }

    @Override
    public void close() {
        System.out.println("Text Document is closed");
    }

}
