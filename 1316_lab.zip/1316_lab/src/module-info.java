/**
 * 
 */
/**
 * 
 */
module Lab_2 {
}